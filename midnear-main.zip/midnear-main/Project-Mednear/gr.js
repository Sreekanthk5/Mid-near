document.getElementById("Home").addEventListener("click",home);
function home(){
    window.location.href ="baby.html";
}