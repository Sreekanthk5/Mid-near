document.getElementById("Home").addEventListener("click",home);
function home(){
    window.location.href ="home.html";
}
function img(){
   document.querySelector(".container").color  
    
}
